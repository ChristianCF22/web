
<?php
function obtenerDatosDashboard($conexion) {
    $datos = [
        "productos" => [],
        "stocks" => [],
        "ventasProductos" => [],
        "cantidadesVendidas" => []
    ];

    $queryProductos = "SELECT nombre, stock FROM productos";
    $resultProductos = $conexion->query($queryProductos);
    while ($fila = $resultProductos->fetch_assoc()) {
        $datos["productos"][] = $fila["nombre"];
        $datos["stocks"][] = $fila["stock"];
    }

    $queryVentas = "SELECT p.nombre, SUM(v.cantidad) AS cantidad_vendida
                    FROM ventas v
                    JOIN productos p ON v.producto_id = p.id
                    GROUP BY p.id";
    $resultVentas = $conexion->query($queryVentas);
    while ($fila = $resultVentas->fetch_assoc()) {
        $datos["ventasProductos"][] = $fila["nombre"];
        $datos["cantidadesVendidas"][] = $fila["cantidad_vendida"];
    }

    return $datos;
}
?>
    