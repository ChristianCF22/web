
<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_web";

$conexion = new mysqli($server, $username, $password, $dbname);
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>
    