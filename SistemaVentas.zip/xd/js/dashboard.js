
document.addEventListener('DOMContentLoaded', function () {
    const stockCtx = document.getElementById('stockChart').getContext('2d');
    const salesCtx = document.getElementById('salesChart').getContext('2d');

    fetch('php/get_dashboard_data.php')
        .then(response => response.json())
        .then(data => {
            new Chart(stockCtx, {
                type: 'bar',
                data: {
                    labels: data.productos,
                    datasets: [{
                        label: 'Stock',
                        data: data.stocks,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)'
                    }]
                },
                options: {
                    responsive: true
                }
            });

            new Chart(salesCtx, {
                type: 'pie',
                data: {
                    labels: data.ventasProductos,
                    datasets: [{
                        data: data.cantidadesVendidas,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
                    }]
                },
                options: {
                    responsive: true
                }
            });
        });
});
    