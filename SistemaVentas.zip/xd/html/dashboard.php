
<?php
include 'php/db_connection.php';
include 'php/dashboard_data.php';
$datos = obtenerDatosDashboard($conexion);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/chart.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Dashboard</h1>
    <div class="row">
        <div class="col-md-6">
            <canvas id="stockChart"></canvas>
        </div>
        <div class="col-md-6">
            <canvas id="salesChart"></canvas>
        </div>
    </div>
</div>
<script src="js/dashboard.js"></script>
</body>
</html>
    